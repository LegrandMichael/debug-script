var unElement = document.getElementById("box");
console.log(mon element);
console.log(unElement)

unElement.remove();
