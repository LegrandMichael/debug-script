fonction hello(){
  alert('Hello');
}

function alerte('prenom'){
  alert('Hello'+prenom);
}

function laBoucle(){
  for(var i=0, i<=10, i++);
  {
    console.log(i);
  }
}

laBoucle();
alert('Pas mal d'erreurs corrigées, BRAVO');
